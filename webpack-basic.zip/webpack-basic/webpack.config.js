// 注意：不要使用ES6的import和export
const path = require('path')
const webpack = require('webpack')
const htmlWebpackPlugin = require('html-webpack-plugin')

module.exports = {
  // 入口
  entry: path.join(__dirname, './src/js/main.js'),

  // 出口
  output: {
    // 输出文件目录
    path: path.join(__dirname, './dist'),
    // 输出文件名称
    filename: 'bundle.js'
  },

  // webpack-dev-server
  devServer: {
    // 简单理解为打开浏览器默认展示哪个目录中的 index.html
    // contentBase: './src',
    // 自动打开浏览器
    open: true,
    // 服务器的端口号
    port: 3000,
    // 热更新：1 开启热更新
    // hot: true
  },

  // 处理非JS的静态资源
  module: {
    rules: [
      // 1 css 资源
      // css-loader：将 CSS 文件中的样式代码，转化为 CommonJS模块
      // style-loader：根据 css-loader 创建的 CommonJS模块，创建 style 标签，追加到 head 中
      { test: /\.css$/, use: ['style-loader', 'css-loader'] },
      // sass
      { test: /\.(scss|sass)$/, use: ['style-loader', 'css-loader', 'sass-loader'] },
      // 图片文件
      // { test: /\.(jpg|jpeg|png|gif|bmp)$/, use: 'url-loader' }
      { 
        test: /\.(jpg|jpeg|png|gif|bmp)$/, 
        use: {
          loader: 'url-loader',   // 表示使用哪个loader
          options: {              // url-loader的参数
            // 作用：使用base64编码图片的限制（大小）值
            limit: 8192           // limit 指定大小（文件占用的磁盘空间大小，单位：byte 字节）
          }
        }
      }
    ]
  },

  // 插件
  plugins: [
    // 热更新：2 启用该插件
    // new webpack.HotModuleReplacementPlugin(),

    new htmlWebpackPlugin({
      // 指定模板文件
      // 内部执行过程：
      // 1 找到模板，在内存中根据模板生成一个文件
      // 2 自动将项目中用到的 js、css 等文件，引入到内存中生成的页面中
      // 在浏览器中看到的页面，就是在内存中生成的页面！！！
      template: path.join(__dirname, './src/index.html')
    })
  ]
}