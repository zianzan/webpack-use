// webpack 的两种使用方式：
// 1 CLI
//   webpack 入口 出口
//   webpack ./src/js/main.js ./dist/bundle.js
// 2 配置文件
//   名称：webpack.config.js

/* 
  webpack 根据入口main.js分析模块的依赖项，得到依赖：jQuery，
  然后，将我们写的main.js文件 与 jquery文件，打包合并为一个 bundle.js 文件输出
  并且，将我们使用的 ES6的import转化为浏览器能够使用的模块化语法
*/

// 导入 jQuery
import $ from 'jquery'

// 实现隔行变色效果
// $('#list > li:odd').css('background-color', 'pink')
// $('#list > li:even').css('background-color', 'green')

const $lis = $('#list > li')
// filter方法，根据指定的选择器，用来筛选元素
$lis.filter(':odd').css('background-color', 'hotpink')
$lis.filter(':even').css('background-color', '#abc')

// CSS文件的处理
import '../css/index.css'

// SASS文件的处理
import '../css/test.scss'
import '../css/test-1.sass'

/* 
  css 文件处理的过程描述：
  1 webpack根据入口分析main.js中的依赖项
  2 当 webpack 看到 import '../css/index.css' 这句话的时候，webpack就知道这是要加载一个css文件
  3 因为webpack默认只能识别js文件，所以，就找到 webpack.config.js 文件中的 module 配置项
  4 遍历 rules 中的每一个规则，使用 test 配置项来与 导入文件路径（'../css/index.css'）进行匹配 /\.css$/.test( '../css/index.css' ) ，当这一项匹配以后，就通过 use 配置项中指定的loader来处理该文件

  5 不同的loader，分别处理（比如：css-loader ....）
*/